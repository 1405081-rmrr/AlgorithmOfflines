#include<iostream>
#include<cstdlib>
#include<cstring>
#include<stdio.h>
#include<random>

using namespace std;

#define LIST_INIT_SIZE 2
#define NULL_VALUE -99999
#define SUCCESS_VALUE 99999

int *degree;

class Edge
{
public:
    int u;
    int v;

    Edge()
    {
        u=-1;
        v=-1;
    }
};

class ArrayListInt
{
public:

    int listMaxSize;
    int* list;
    int length;

    ArrayListInt()
    {
        listMaxSize = LIST_INIT_SIZE;
        list = new int[listMaxSize] ;
        length = 0 ;
    }

    void initializeList()
    {
        listMaxSize = LIST_INIT_SIZE;
        list = new int[listMaxSize] ;
        length = 0 ;
    }

    int getLength()
    {
        return length;
    }

    int searchItem(int item)
    {
        int i = 0;
        for (i = 0; i < length; i++)
        {
            if( list[i] == item )
                return i;
        }
        return NULL_VALUE;
    }

    int insertItem(int newitem)
    {
        if(listMaxSize==0)
        {
            initializeList();
        }
        int * tempList ;
        if (length == listMaxSize)
        {
            listMaxSize = 2 * listMaxSize ;
            tempList = new int[listMaxSize] ;
            int i;
            for( i = 0; i < length ; i++ )
            {
                tempList[i] = list[i] ;
            }
            delete [] list ;
            list = tempList ;
        };

        list[length] = newitem ;
        length++ ;
        return SUCCESS_VALUE ;
    }

    void shrink()
    {
        if((length==listMaxSize/2)&&(listMaxSize>LIST_INIT_SIZE))
        {
            int* templist;
            listMaxSize=listMaxSize/2;
            templist=new int[listMaxSize];
            int i;
            for(i=0; i<length; i++)
            {
                templist[i]=list[i];
            }
            delete [] list;
            list=templist;
        }
    }

    int deleteItemAt(int position)
    {
        if ( position >= length )
            return NULL_VALUE;
        list[position] = list[length-1] ;
        length-- ;
        shrink();
        return SUCCESS_VALUE ;
    }


    int deleteItem(int item)
    {
        int position;
        position = searchItem(item) ;
        if ( position == NULL_VALUE )
            return NULL_VALUE;
        deleteItemAt(position) ;
        shrink();
        return SUCCESS_VALUE ;
    }

    void deleteLast()
    {
        length--;
        shrink();
    }

    void clear()
    {
        length=0;
        listMaxSize=0;
        delete [] list;
    }

    void deleteAll()
    {
        length=0;
        if(listMaxSize>LIST_INIT_SIZE)
        {
            int* templist;
            listMaxSize=LIST_INIT_SIZE;
            templist=new int[listMaxSize];
            list=templist;
        }
    }

    void printList()
    {
        int i;
        for(i=0; i<length; i++)
        {
            cout<<list[i]<<" ";
        }
        cout<<"Current size: "<<listMaxSize<<", current length: "<<length<<"\n";
    }
};

class ArrayListEdge
{
public:

    int listMaxSize;
    Edge *list;
    int length;

    ArrayListEdge()
    {
        listMaxSize = LIST_INIT_SIZE;
        list = new Edge[listMaxSize] ;
        length = 0 ;
    }

    void initializeList()
    {
        listMaxSize = LIST_INIT_SIZE;
        list = new Edge[listMaxSize] ;
        length = 0 ;
    }

    int getLength()
    {
        return length;
    }

    int searchItem(Edge item)
    {
        int i = 0;
        for (i = 0; i < length; i++)
        {
            if((list[i].u == item.u) && (list[i].v == item.v))
                return i;
        }
        return NULL_VALUE;
    }

    int insertItem(Edge newitem)
    {
        if(listMaxSize==0)
        {
            initializeList();
        }
        Edge *tempList ;
        if (length == listMaxSize)
        {
            listMaxSize = 2 * listMaxSize;
            tempList = new Edge[listMaxSize];
            int i;
            for( i = 0; i < length ; i++ )
            {
                tempList[i] = list[i] ;
            }
            delete [] list ;
            list = tempList ;
        };

        list[length].u = newitem.u;
        list[length].v = newitem.v;
        length++ ;
        /*list[length].u = newitem.v;
        list[length].v = newitem.u;
        length++ ;*/

        return SUCCESS_VALUE ;
    }

    void shrink()
    {
        if((length==listMaxSize/2)&&(listMaxSize>LIST_INIT_SIZE))
        {
            Edge *templist;
            listMaxSize=listMaxSize/2;
            templist = new Edge[listMaxSize];
            int i;
            for(i=0; i<length; i++)
            {
                templist[i]=list[i];
            }
            delete [] list;
            list=templist;
        }
    }

    int deleteItemAt(int position)
    {
        if (position >= length)
            return NULL_VALUE;
        list[position] = list[length-1] ;
        length-- ;
        shrink();
        return SUCCESS_VALUE ;
    }


    int deleteItem(Edge item)
    {
        int position;
        position = searchItem(item) ;
        if (position == NULL_VALUE)
            return NULL_VALUE;
        deleteItemAt(position) ;
        shrink();
        return SUCCESS_VALUE ;
    }

    void deleteLast()
    {
        length--;
        shrink();
    }

    void clear()
    {
        length=0;
        listMaxSize=0;
        delete [] list;
    }

    void deleteAll()
    {
        length=0;
        if(listMaxSize>LIST_INIT_SIZE)
        {
            Edge *templist;
            listMaxSize=LIST_INIT_SIZE;
            templist=new Edge[listMaxSize];
            delete [] list;
            list=templist;
        }
    }

    void printList()
    {
        int i;
        for(i=0; i<length; i++)
        {
            cout<<"("<<list[i].u<<","<<list[i].v<<")"<<" ";
        }
        cout<<"\nCurrent size: "<<listMaxSize<<", current length: "<<length<<"\n";
    }

    Edge extractMaxDegree()
    {
        int i, index, maxDegree = -INT_MAX, deg;
        Edge temp;

        for(i=0; i<length; i++)
        {
            deg = degree[list[i].u]+degree[list[i].v];
            if(deg>maxDegree)
            {
                maxDegree = deg;
                temp = list[i];
                index = i;
            }
        }
        //cout<<temp.u<<" "<<temp.v<<" "<<index<<endl;
        deleteItemAt(index);
        return temp;
    }

    Edge extractRandom()
    {
        int index;
        Edge temp;
        index = (rand())%length;

        temp = list[index];

        deleteItemAt(index);
        return temp;
    }
};
int main(void)
{
    ArrayListEdge myList, myListr;
    ArrayListInt vc, vcr;
    //vc.printList();
    //myList.initializeList();
    //vc.initializeList();

    int i,vertices, edges;
    cin>>vertices>>edges;
    degree = new int[vertices+1];
    Edge item;

    for(i=0; i<vertices+1; i++)
    {
        degree[i]=0;
    }

    for(i=0; i<edges; i++)
    {
        cin>>item.u>>item.v;
        myList.insertItem(item);
        myListr.insertItem(item);
        degree[item.u]++;
        degree[item.v]++;
    }

    //myList.printList();
    cout<<"\n";
    /*for(i=0; i<vertices+1; i++)
    {
        cout<<degree[i]<<" ";
    }*/

    //cout<<"\n"<<myList.getLength()<<" "<<myListr.getLength()<<endl;

    while(1)
    {
        if(myList.getLength()!=0)
        {
            item = myList.extractMaxDegree();
            //cout<<item.u<<" "<<item.v<<endl;
        }
        //myList.printList();
        //vc.printList();
        vc.insertItem(item.u);
        vc.insertItem(item.v);
        //vc.printList();
        degree[item.u]=0;
        degree[item.v]=0;

        for(i=0; i<myList.getLength(); i++)
        {
            //cout<<"YES!"<<endl;
            if((myList.list[i].u==item.u)||(myList.list[i].u==item.v)||(myList.list[i].v==item.u)||(myList.list[i].v==item.v))
            {
                if(degree[myList.list[i].u]==0)
                    degree[myList.list[i].v]--;
                else if(degree[myList.list[i].v]==0)
                    degree[myList.list[i].u]--;

                //cout<<"YES!"<<endl;
                myList.deleteItemAt(i);
                i--;
                //cout<<"YES!"<<endl;
            }
        }
        if(myList.getLength()==0)
            break;
    }

    while(1)
    {
        if(myListr.getLength()!=0)
        {
            item = myListr.extractRandom();
            //cout<<item.u<<" "<<item.v<<endl;
        }

        vcr.insertItem(item.u);
        vcr.insertItem(item.v);

        for(i=0; i<myListr.getLength(); i++)
        {
            //cout<<"YES!"<<endl;
            if((myListr.list[i].u==item.u)||(myListr.list[i].u==item.v)||(myListr.list[i].v==item.u)||(myListr.list[i].v==item.v))
            {
                myListr.deleteItemAt(i);
                i--;
                //cout<<"YES!"<<endl;
            }
        }
        if(myListr.getLength()==0)
            break;
    }

    //vc.printList();
    cout<<"\nMin Vertex Cover Greedy: Size "<<vc.getLength()<<endl;
    cout<<"\nMin Vertex Cover Random: Size "<<vcr.getLength()<<endl;

    return 0;
}
